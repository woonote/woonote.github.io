<?php
/**
 * @package WooNote
 * @version 1.2.0
 */
/*
Plugin Name: WooNote
Plugin URI: http://wordpress.org/plugins/woonote/
Description: Private note app, sync all notes to your site. Simple, fast and low memory usage, No unnecessary features to disturb your thoughts!
Author: w3cplus
Version: 1.2.0
Author URI: https://woonote.github.io/
*/

add_action('init', 'mynote_action_init');

function mynote_action_init() {
  mynote_register_note_post();
}

add_filter( 'jwt_auth_whitelist', function ( $endpoints ) {
  $_endpoints = array(
    '/wp-json/mynote/v1/ping'
  );

  return array_unique( array_merge( $endpoints, $_endpoints ) );
});

function woonote_admin_theme() {
  wp_enqueue_style('woonote-admin-theme', plugin_dir_url(__FILE__).'/style.css');
}

add_action('admin_enqueue_scripts', 'woonote_admin_theme');

function woonote_plugin_activate() {
  global $wpdb;
  $userTableName = $wpdb->prefix . 'mynote_user';
  $termTableName = $wpdb->prefix . 'mynote_terms';
  $relTableName = $wpdb->prefix . 'mynote_term_relation';
  $wpdb_collate = $wpdb->collate;
  $sqls = array(
    "CREATE TABLE {$userTableName} (
      `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `uid` INT(11) UNSIGNED NOT NULL,
      `uuid` VARCHAR(50) NOT NULL,
      `secret` VARCHAR(80) NOT NULL,
      `created_time` INT(11) UNSIGNED NOT NULL DEFAULT '0',
      `updated_time` INT(11) UNSIGNED NOT NULL DEFAULT '0',
      `status` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
      PRIMARY KEY (`id`) USING BTREE,
      UNIQUE INDEX `uuid` (`uuid`) USING BTREE,
      INDEX `uid` (`uid`) USING BTREE
    )
    COLLATE='{$wpdb_collate}'
    ENGINE=InnoDB;",

    "CREATE TABLE {$termTableName} (
      `term_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `uid` INT(10) UNSIGNED NOT NULL DEFAULT '0',
      `slug` VARCHAR(120) NOT NULL DEFAULT '0',
      `name` VARCHAR(100) NOT NULL DEFAULT '0',
      `taxonomy` VARCHAR(24) NOT NULL DEFAULT '0',
      `parent` INT(11) UNSIGNED NOT NULL DEFAULT '0',
      `status` TINYINT(4) UNSIGNED NOT NULL DEFAULT '1',
      PRIMARY KEY (`term_id`) USING BTREE,
      INDEX `uid_idx` (`uid`) USING BTREE
    )
    COLLATE='{$wpdb_collate}'
    ENGINE=InnoDB;",

    "CREATE TABLE {$relTableName} (
      `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `term_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
      `post_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
      PRIMARY KEY (`id`) USING BTREE,
      INDEX `term_id_idx` (`term_id`) USING BTREE,
      INDEX `post_id_idx` (`post_id`) USING BTREE
    )
    COLLATE='{$wpdb_collate}'
    ENGINE=InnoDB;"
  );

  require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
  dbDelta( $sqls );
}
register_activation_hook( __FILE__, 'woonote_plugin_activate' );

function mynote_register_note_post() {
  $labels = array(
    'name'               => _x( 'Notes', 'post type general name', 'your-plugin-textdomain' ),
    'singular_name'      => _x( 'Note', 'post type singular name', 'your-plugin-textdomain' ),
    'menu_name'          => _x( 'Notes', 'admin menu', 'your-plugin-textdomain' ),
    'name_admin_bar'     => _x( 'Note', 'add new on admin bar', 'your-plugin-textdomain' ),
    'add_new'            => _x( 'Add New', 'note', 'your-plugin-textdomain' ),
    'add_new_item'       => __( 'Add New Note', 'your-plugin-textdomain' ),
    'new_item'           => __( 'New Note', 'your-plugin-textdomain' ),
    'edit_item'          => __( 'Edit Note', 'your-plugin-textdomain' ),
    'view_item'          => __( 'View Note', 'your-plugin-textdomain' ),
    'all_items'          => __( 'All Notes', 'your-plugin-textdomain' ),
    'search_items'       => __( 'Search Notes', 'your-plugin-textdomain' ),
    'parent_item_colon'  => __( 'Parent Notes:', 'your-plugin-textdomain' ),
    'not_found'          => __( 'No notes found.', 'your-plugin-textdomain' ),
    'not_found_in_trash' => __( 'No notes found in Trash.', 'your-plugin-textdomain' )
  );
  $args = array(
    'labels'             => $labels,
    'description'        => __( 'Description.', 'your-plugin-textdomain' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'note' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'menu_icon'          => 'dashicons-media-document',
    'show_in_rest'       => false,
    // 'rest_base'          => 'notes',
    // 'rest_controller_class' => 'WP_REST_Posts_Controller',
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
  );

  register_post_type( 'note', $args );
}

class MyNote_Common_REST_Controller extends WP_REST_Controller {
  // Here initialize our namespace and resource name.
  public function __construct() {
    $this->namespace     = '/mynote/v1';
    $this->resource_name = 'notes';
    $this->uid = is_user_logged_in() ? get_current_user_id() : 0;
  }

  // Register our routes.
  public function register_routes() {
    // note api
    register_rest_route( $this->namespace, '/' . $this->resource_name, array(
        // Here we register the readable endpoint for collections.
        array(
            'methods'   => 'GET',
            'callback'  => array( $this, 'get_items' ),
            'permission_callback' => array( $this, 'create_item_permissions_check' ),
        ),
        array(
          'methods'             => WP_REST_Server::CREATABLE,
          'callback'            => array( $this, 'create_item' ),
          'permission_callback' => array( $this, 'create_item_permissions_check' ),
          'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
        )
    ) );
    register_rest_route( $this->namespace, '/' . $this->resource_name . '/(?P<id>[\d]+)', array(
      'args' => array(
          'id' => array(
            'description' => __( 'Unique identifier for the post.' ),
            'type'        => 'integer',
          ),
        ),
        // Notice how we are registering multiple endpoints the 'schema' equates to an OPTIONS request.
        array(
            'methods'   => 'GET',
            'callback'  => array( $this, 'get_item' ),
            'permission_callback' => array( $this, 'create_item_permissions_check' ),
        ),
        array(
          'methods'             => WP_REST_Server::EDITABLE,
          'callback'            => array( $this, 'update_item' ),
          'permission_callback' => array( $this, 'update_item_permissions_check' ),
          'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::EDITABLE ),
        ),
        array(
          'methods'             => WP_REST_Server::DELETABLE,
          'callback'            => array( $this, 'delete_item' ),
          'permission_callback' => array( $this, 'delete_item_permissions_check' ),
          'args'                => array(
            'force' => array(
              'type'        => 'boolean',
              'default'     => false,
              'description' => __( 'Whether to bypass Trash and force deletion.' ),
            ),
          ),
        )
    ) );

    // folder api ------------------------------------------------
    register_rest_route( $this->namespace, '/folders', array(
        // Here we register the readable endpoint for collections.
        array(
            'methods'   => 'GET',
            'callback'  => array( $this, 'get_folders' ),
            'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
        ),
        array(
          'methods'             => WP_REST_Server::CREATABLE,
          'callback'            => array( $this, 'create_folder' ),
          'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
        )
    ) );
    register_rest_route( $this->namespace, '/folders' . '/(?P<id>[\d]+)', array(
      'args' => array(
          'id' => array(
            'description' => __( 'Unique identifier for the post.' ),
            'type'        => 'integer',
          ),
        ),
        // Notice how we are registering multiple endpoints the 'schema' equates to an OPTIONS request.
        array(
            'methods'   => 'GET',
            'callback'  => array( $this, 'get_folder' ),
            'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
        ),
        array(
          'methods'             => WP_REST_Server::EDITABLE,
          'callback'            => array( $this, 'update_folder' ),
          'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
          'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::EDITABLE ),
        ),
        array(
          'methods'             => WP_REST_Server::DELETABLE,
          'callback'            => array( $this, 'delete_folder' ),
          'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
          'args'                => array(
            'force' => array(
              'type'        => 'boolean',
              'default'     => false,
              'description' => __( 'Whether to bypass Trash and force deletion.' ),
            ),
          ),
        )
    ) );
    register_rest_route( $this->namespace, '/folders/add_note', array(
        array(
          'methods'             => 'POST',
          'callback'            => array( $this, 'folder_add_note' ),
          'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
        )
    ) );

    register_rest_route( $this->namespace, '/config', array(
      array(
            'methods'   => 'GET',
            'callback'  => array( $this, 'get_config' ),
            'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
        ),
    ) );
    register_rest_route( $this->namespace, '/activate', array(
      array(
        'methods'             => 'POST',
        'callback'            => array( $this, 'activate' ),
        'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
      )
    ) );
    register_rest_route( $this->namespace, '/ping', array(
      array(
        'methods'   => 'GET',
        'callback'  => array( $this, 'ping_check' ),
        // 'permission_callback' => array( $this, 'folder_operate_permissions_check' ),
      ),
    ));
  }

  /**
   * Check permissions for the posts.
   *
   * @param WP_REST_Request $request Current request.
   */
  public function get_items_permissions_check( $request ) {
    if ( ! current_user_can( 'read' ) ) {
        return new WP_Error( 'rest_forbidden', esc_html__( 'You cannot view the post resource.' ), array( 'status' => $this->authorization_status_code() ) );
    }
    return true;
  }

  /**
   * Grabs the five most recent posts and outputs them as a rest response.
   *
   * @param WP_REST_Request $request Current request.
   */
  public function get_items( $request ) {
    $args = array(
      'page' => empty($request['page']) ? 1 : (int)$request['page'],
      'per_page' => empty($request['per_page']) ? 20 : (int)$request['per_page'],
      'post_type' => 'note',
      'post_status' => 'private',
      'uid' => $this->uid,
      'folder_id' => empty($request['folder_id']) ? null : (int)$request['folder_id'],
      'resp_type' => empty($request['resp_type']) ? null : $request['resp_type'],
      'orderby' => empty($request['orderby']) ? null : $request['orderby'],
      'order' => empty($request['order']) ? null : $request['order']
    );

    $data = mynote_func_get_notes( $args );

    if (!$data || $data['total'] == 0) {
      return __returnResult(200, 'no_data');
    }

    $result = array();

    foreach ( $data['items'] as $item ) {
      $result[] = $this->prepare_item_for_response( $item, $request );
    }

    return __returnResult(200, 'ok', array('total' => $data['total'], 'current_page' => $args['page'], 'per_page' => $data['per_page'], 'items' => $result), true);
  }

  /**
   * Check permissions for the posts.
   *
   * @param WP_REST_Request $request Current request.
   */
  public function get_item_permissions_check( $request ) {
    if ( ! current_user_can( 'read' ) ) {
        return new WP_Error( 'rest_forbidden', esc_html__( 'You cannot view the post resource.' ), array( 'status' => $this->authorization_status_code() ) );
    }
    return true;
  }

  /**
   * Gets post data of requested post id and outputs it as a rest response.
   *
   * @param WP_REST_Request $request Current request.
   */
  public function get_item( $request ) {
    $id = (int) $request['id'];
    $post = mynote_func_get_note($id, $this->uid);

    if ( empty( $post ) ) {
      return __returnResult(400, 'not_found');
    }

    $folder = mynote_func_get_folder_by_note($id);

    $response = $this->prepare_item_for_response( $post, $request );

    if ($folder) $response['term_id'] = (int)$folder['term_id'];

    return __returnResult(200, 'ok', $response);
  }

  public function create_item_permissions_check( $request ) {
    if ($this->uid == 0 || ! empty( $request['id'] ) ) {
      return new WP_Error(
        'rest_post_exists',
        __( 'Cannot create existing post.' ),
        array( 'status' => 400 )
      );
    }

    return true;
  }

  public function create_item( $request ) {
    if ( ! empty( $request['id'] ) ) {
      return __returnResult(500, 'rest_post_exists');
    }

    $prepared_post = $this->prepare_item_for_database( $request );

    if ( is_wp_error( $prepared_post ) ) {
      return __returnResult(400, 'prepare_error');
    }

    $post_id = wp_insert_post( wp_slash( (array) $prepared_post ), true, false );

    if ( is_wp_error( $post_id ) ) {

      if ( 'db_insert_error' === $post_id->get_error_code() ) {
        $post_id->add_data( array( 'status' => 500 ) );
      } else {
        $post_id->add_data( array( 'status' => 400 ) );
      }

      return __returnResult(400, 'db_insert_error');
    }

    $post = mynote_func_get_note( $post_id, $this->uid, true);

    if (isset($request['folder_id']) && $request['folder_id'] >= 0) {
      mynote_func_folder_add_note((int)$request['folder_id'], $post_id, $this->uid);
    }

    do_action( "rest_insert_note", $post, $request, true );

    do_action( "rest_after_insert_note", $post, $request, true );

    wp_after_insert_post( $post, false, null );

    $response = $this->prepare_item_for_response( $post, $request );
    // $response = rest_ensure_response( $response );

    // $response->set_status( 201 );
    $folder = mynote_func_get_folder_by_note($post_id);

    if ($folder) $response['term_id'] = (int)$folder['term_id'];

    return __returnResult(200, 'ok', $response);
  }

  public function update_item_permissions_check( $request ) {
    $post = mynote_func_get_note($request['id'], $this->uid);
    if (!$post || is_wp_error( $post ) ) {
      return new WP_Error(
        'rest_cannot_edit',
        __( 'Sorry, you are not allowed to edit this post.' ),
        array( 'status' => rest_authorization_required_code() )
      );
    }

    return true;
  }

  protected function parseVerTime($content) {
    $items = explode('##', $content);
    if (count($items) == 2) {
      $items = explode(':', $items[0]);
      return $items;
    }
    return [0, 0];
  }

  protected function backupNote( $request ) {

    $prepared_post = $this->prepare_item_for_database( $request );


    $post_id = wp_insert_post( wp_slash( (array) $prepared_post ), true, false );

    if ( is_wp_error( $post_id ) ) {
      return null;
    }

    $post = mynote_func_get_note( $post_id, $this->uid, true);

    if (isset($request['folder_id']) && $request['folder_id'] >= 0) {
      mynote_func_folder_add_note((int)$request['folder_id'], $post_id, $this->uid);
    }

    do_action( "rest_insert_note", $post, $request, true );

    do_action( "rest_after_insert_note", $post, $request, true );

    wp_after_insert_post( $post, false, null );

    return $post_id;
  }

  protected function verTimeToDate($time, $format = 'Ymd_H:i:s') {
    $timestr = is_string($time) ? $time : sprintf('%d', $time);
    $len = strlen($timestr);
    if ($len > 10) {
      $time = intval(substr($timestr, 0, 10));
    } elseif ($len < 10) {
      return $time;
    }

    return date($format, (int)$time);
  }

  /**
   * Updates a single post.
   *
   * @since 4.7.0
   *
   * @param WP_REST_Request $request Full details about the request.
   * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
   */
  public function update_item( $request ) {
    $nodeId = (int)$request['id'];

    $_note = mynote_func_get_note( $nodeId, $this->uid);

    if (!$_note || is_wp_error( $_note ) ) {
      return __returnResult(500, 'not_found');
    }

    $oldVerTime = $this->parseVerTime($_note->post_content);
    $newVerTime = $this->parseVerTime($request['content']);
    $backupNoteId = 0;

    if ($oldVerTime[1] != $newVerTime[0]) {
      $folder = mynote_func_get_folder_by_note($nodeId);
      $backupNoteId = $this->backupNote(array(
        'title' => $_note->post_title.'[nosync_'.$this->verTimeToDate($oldVerTime[1]).']',
        'content' => $_note->post_content,
        'folder_id' => $folder ? $folder['term_id'] : 0
      ));
    }

    $post = $this->prepare_item_for_database( $request );

    if ( is_wp_error( $post ) ) {
      return __returnResult(400, 'note_prepare_error');
    }

    // Convert the post object to an array, otherwise wp_update_post() will expect non-escaped input.
    $post_id = wp_update_post( wp_slash( (array) $post ), true, false );

    if ( is_wp_error( $post_id ) ) {
      if ( 'db_update_error' === $post_id->get_error_code() ) {
        $post_id->add_data( array( 'status' => 500 ) );
      } else {
        $post_id->add_data( array( 'status' => 400 ) );
      }
      return __returnResult(400, 'db_update_error');
    }

    $post = mynote_func_get_note($nodeId, $this->uid, true);

    if (isset($request['folder_id']) && $request['folder_id'] >= 0) {
      mynote_func_folder_add_note((int)$request['folder_id'], $nodeId, $this->uid);
    }

    /** This action is documented in wp-includes/rest-api/endpoints/class-wp-rest-posts-controller.php */
    do_action( "rest_insert_note", $post, $request, false );

    /** This action is documented in wp-includes/rest-api/endpoints/class-wp-rest-posts-controller.php */
    do_action( "rest_after_insert_note", $post, $request, false );

    wp_after_insert_post( $post, true, $post_before );

    $response = $this->prepare_item_for_response( $post, $request );

    $folder = mynote_func_get_folder_by_note($nodeId);

    if ($folder) $response['term_id'] = (int)$folder['term_id'];

    return __returnResult(200, $backupNoteId > 0 ? 'need_sync' : 'ok', $response);
  }

  /**
   * Checks if a given request has access to delete a post.
   *
   * @since 4.7.0
   *
   * @param WP_REST_Request $request Full details about the request.
   * @return true|WP_Error True if the request has access to delete the item, WP_Error object otherwise.
   */
  public function delete_item_permissions_check( $request ) {
    $post = mynote_func_get_note( $request['id'], $this->uid);
    if (!$post || is_wp_error( $post ) ) {
      return new WP_Error(
        'rest_cannot_delete',
        __( 'Sorry, you are not allowed to delete this post.' ),
        array( 'status' => rest_authorization_required_code() )
      );
    }

    return true;
  }

  /**
   * Deletes a single post.
   *
   * @since 4.7.0
   *
   * @param WP_REST_Request $request Full details about the request.
   * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
   */
  public function delete_item( $request ) {
    $post = mynote_func_get_note( $request['id'], $this->uid);
    if (!$post || is_wp_error( $post ) ) {
      return __returnResult(400, 'rest_user_cannot_delete_post');
    }

    $id = $post->ID;

    // Otherwise, only trash if we haven't already.
    if ( 'trash' === $post->post_status ) {
      return __returnResult(400, 'rest_already_trashed');
    }

    /*
     * (Note that internally this falls through to `wp_delete_post()`
     * if the Trash is disabled.)
     */
    $result   = wp_trash_post( $id );
    $post     = mynote_func_get_note( $id , $this->uid, true);
    $response = $this->prepare_item_for_response( $post, $request );

    if ( ! $result ) {
      return __returnResult(400, 'rest_cannot_delete');
    }

    mynote_func_folder_delete_note(0, $id);
    /**
     * Fires immediately after a single post is deleted or trashed via the REST API.
     *
     * They dynamic portion of the hook name, `$this->post_type`, refers to the post type slug.
     *
     * Possible hook names include:
     *
     *  - `rest_delete_post`
     *  - `rest_delete_page`
     *  - `rest_delete_attachment`
     *
     * @since 4.7.0
     *
     * @param WP_Post          $post     The deleted or trashed post.
     * @param WP_REST_Response $response The response data.
     * @param WP_REST_Request  $request  The request sent to the API.
     */
    do_action( "rest_delete_note", $post, $response, $request );

    return __returnResult(200, 'ok');
  }

  /**
   * Check permissions for the folder.
   *
   * @param WP_REST_Request $request Current request.
   */
  public function folder_operate_permissions_check( $request ) {
    if ($this->uid == 0) {
        return new WP_Error( 'rest_forbidden', esc_html__( 'You cannot perform this operation.' ), array( 'status' => $this->authorization_status_code() ) );
    }
    return true;
  }

  protected function prepare_item_for_database( $request ) {
    $prepared_post  = new stdClass();
    $current_status = '';
    $existing_post = null;
    $currentDate = date('Y-m-d H:i:s');

    // Post ID.
    if ( isset( $request['id'] ) ) {
      $existing_post = mynote_func_get_note( $request['id'], $this->uid);
      if ( is_wp_error( $existing_post ) ) {
        return $existing_post;
      }

      $prepared_post->ID = $existing_post->ID;
    }

    if ($existing_post) {
      $prepared_post->post_date = $existing_post->post_date;
      $prepared_post->post_date_gmt = $existing_post->post_date_gmt;
    } else {
      $prepared_post->post_date = $prepared_post->post_date_gmt = $currentDate;
    }

    $prepared_post->post_author = $this->uid;
    $prepared_post->post_modified = $prepared_post->post_modified_gmt = $currentDate;

    // Post title.
    if (isset( $request['title'] ) ) {
      if ( is_string( $request['title'] ) ) {
        $prepared_post->post_title = $request['title'];
      } elseif ( ! empty( $request['title']['raw'] ) ) {
        $prepared_post->post_title = $request['title']['raw'];
      }
    }

    // Post content.
    if (isset( $request['content'] ) ) {
      if ( is_string( $request['content'] ) ) {
        $prepared_post->post_content = $request['content'];
      } elseif ( isset( $request['content']['raw'] ) ) {
        $prepared_post->post_content = $request['content']['raw'];
      }
    }

    // Post type.
    $prepared_post->post_type = 'note';

    // Post status.
    $prepared_post->post_status = 'private';

    // Post slug.
    $prepared_post->post_name = '';

    // Comment status.
    $prepared_post->comment_status = 'closed';

    // Ping status.
    $prepared_post->ping_status = 'closed';

    $prepared_post->page_template = null;

    /**
     * Filters a post before it is inserted via the REST API.
     *
     * The dynamic portion of the hook name, `$this->post_type`, refers to the post type slug.
     *
     * Possible hook names include:
     *
     *  - `rest_pre_insert_post`
     *  - `rest_pre_insert_page`
     *  - `rest_pre_insert_attachment`
     *
     * @since 4.7.0
     *
     * @param stdClass        $prepared_post An object representing a single post prepared
     *                                       for inserting or updating the database.
     * @param WP_REST_Request $request       Request object.
     */
    return apply_filters( "rest_pre_insert_note", $prepared_post, $request );

  }

  public function folder_add_note($request) {
    $result = false;
    
    $folderId = isset($request['folder_id']) && is_numeric($request['folder_id']) ? (int)$request['folder_id'] : -1;
    $noteId = empty($request['note_id']) ? 0 : (int)$request['note_id'];

    if ($noteId == 0 || $folderId < 0) {
      return array('statusCode' => 500, 'code' => 'no_params');
    }

    $note = mynote_func_get_note($noteId, $this->uid);
    if (!$note) {
      return array('statusCode' => 500, 'code' => 'note_not_existed');
    }

    if ($folderId > 0) {
      $result = mynote_func_folder_add_note($folderId, $noteId, $this->uid);
    } else {
      $result = mynote_func_folder_delete_note($folderId, $noteId);
    }

    return array('statusCode' => $result ? 200 : 500);
  }

  public function get_folder( $request ) {
    $term = mynote_func_get_folder( $request['id'], $this->uid);

    return array('statusCode' => 200, 'code' => 'ok', 'data' => $this->prepare_folder_for_response($term));
  }

  public function get_folders( $request ) {
    $args = array(
      'uid' => $this->uid,
      'taxonomy' => 'folder'
    );
    $terms = mynote_func_get_folders( $args );
    $result = array();
    foreach ($terms as $item) {
      $result[] = $this->prepare_folder_for_response($item);
    }
    return array('statusCode' => 200, 'code' => 'ok', 'total' => count($result), 'data' => $result);
  }

  protected function prepare_folder_for_response($data) {
    $item = array();

    $keys = array(
       'term_id' => 'term_id',
       'uid' => 'uid',
       'name' => 'name', 
       'taxonomy' => 'taxonomy',
       'parent' => 'parent', 
       'status' => 'status'
    );
    foreach ($keys as $key => $name) {
      if ($key == 'name' || $key == 'taxonomy') {
        $item[$key] = $data[$name];
      } else {
        $item[$key] = (int) $data[$name];
      }
    }

    return $item;
  }

  public function create_folder( $request ) {
    if (!empty($request['id'])) {
      $term = mynote_func_get_folder( $request['id'], $this->uid);
      if ($term) return array('statusCode' => 500, 'code' => 'folder_existed');
    }

    global $wpdb;
    if (!$request['name']) return array('statusCode' => 500, 'code' => 'folder_name_invalid');

    $slug = 'folder_'.substr(microtime(), 2, 8);
    $update_data = array('uid' => $this->uid, 'slug' => $slug, 'taxonomy' => 'folder', 'status' => 1);
    $fmt = array('%d', '%s', '%s', '%d');

    if (!empty($request['name'])) {
      $update_data['name'] = $request['name'];
      $fmt[] = '%s';
    }

    if (isset($request['parent']) && is_numeric($request['parent'])) {
      $update_data['parent'] = (int)$request['parent'];
      $fmt[] = '%d';
      if ($update_data['parent']) {
        $term = mynote_func_get_folder($update_data['parent'], $this->uid);
        if (!$term) {
          return array('statusCode' => 500, 'code' => 'parent_not_found');
        }
      }
    }

    $result = $wpdb->insert($wpdb->prefix.'mynote_terms', $update_data, $fmt);

    return array('statusCode' => $result > 0 ? 200 : 500, 'data' => mynote_func_get_folder_by_slug($slug, $this->uid));
  }

  public function update_folder( $request ) {
    global $wpdb;
    $term = mynote_func_get_folder($request['id'], $this->uid);
    if (!$term) {
      return array('statusCode' => 500, 'code' => 'not_found');
    }

    $update_data = array();
    $fmt = array();

    if (!empty($request['name'])) {
      $update_data['name'] = $request['name'];
      $fmt[] = '%s';
    }
    //  else {
    //   return array('statusCode' => 500, 'code' => 'folder_name_invalid');
    // }

    if (isset($request['parent']) && is_numeric($request['parent'])) {
      $update_data['parent'] = (int)$request['parent'];
      $fmt[] = '%d';
    }

    if ($update_data['parent']) {
      $term = mynote_func_get_folder($update_data['parent'], $this->uid);
      if (!$term) {
        return array('statusCode' => 500, 'code' => 'parent_not_found');
      }
    }
    
    if (count($update_data) == 0) {
      return array('statusCode' => 500, 'code' => 'not_params');
    }

    $result = $wpdb->update($wpdb->prefix.'mynote_terms', $update_data, array('term_id' => (int)$request['id'], 'uid' => $this->uid), $fmt);

    return array('statusCode' => $result > 0 ? 200 : 500, 'data' => mynote_func_get_folder($request['id'], $this->uid, true));
  }

  public function delete_folder( $request ) {
    global $wpdb;
    $term = mynote_func_get_folder( $request['id'], $this->uid);
    if (!$term) {
      return array('statusCode' => 500, 'code' => 'not_found');
    }

    $count = $wpdb->get_var($wpdb->prepare('SELECT COUNT(id) as total FROM '.$wpdb->prefix.'mynote_term_relation WHERE term_id=%d', (int)$request['id']));

    if ($count > 0) return array('statusCode' => 500, 'code' => 'have_notes');

    $update_data = array('status' => 0);
    $fmt = array('%d');

    $result = $wpdb->update($wpdb->prefix.'mynote_terms', $update_data, array('term_id' => (int)$request['id'], 'uid' => $this->uid, 'status' => 1), $fmt);

    return array('statusCode' => $result > 0 ? 200 : 500);
  }

  public function get_config( $request ) {
    global $wpdb;

    $data = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_user WHERE uid=%d and status=1 LIMIT 1", $this->uid) , ARRAY_A);

    $options = get_option('woonote_plugin_options');
    if (!$data) {
      $hash = get_option('woonote_uuid_hash');
      $count = get_option('woonote_user_count');
      $data = array(
        'count' => $count ? $count : 0,
        'hash' => $hash ? $hash : ''
      );
    } else {
      $data = array(
        'uuid' => $data['uuid'],
        'secret' => $data['secret']
      );
    }
    
    $data['app_id'] = $options['app_id'];
    $data['app_key'] = $options['app_key'] ? substr($options['app_key'], -40) : '';

    return array('statusCode' => 200, 'code' => 'ok', 'data' => $data);
  }

  public function ping_check( $request ) {
    return array('statusCode' => 200, 'code' => 'ok');
  }

  public function activate( $request ) {
    global $wpdb;

    $update_data = array();
    $fmt = array();
    $val = array();
    $config = array();

    if (empty($request['hash']) || !preg_match('/^[a-z0-9]{40}$/i', $request['hash'])) {
      return array('statusCode' => 500, 'code' => 'invalid_hash');
    }

    $count = intval(get_option('woonote_user_count'));
    if (empty($request['count']) || $request['count'] <= $count) {
      return array('statusCode' => 500, 'code' => 'invalid_count');
    }

    $val['uid'] = $this->uid;
    $fmt[] = '%d';

    if (!empty($request['uuid']) && preg_match('/^[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}$/i', $request['uuid'])) {
      $val['uuid'] = esc_sql($request['uuid']);
      $fmt[] = '%s';
    } else {
      return array('statusCode' => 500, 'code' => 'invalid_uuid');
    }

    if (!empty($request['secret']) && preg_match('/^[a-z0-9]{44}$/i', $request['secret'])) {
      $val['secret'] = esc_sql($request['secret']);
      $fmt[] = '%s';
    } else {
      return array('statusCode' => 500, 'code' => 'invalid_secret');
    }

    $val['created_time'] = $val['updated_time'] = time();
    $fmt[] = '%d';
    $fmt[] = '%d';

    $val['status'] = 1;
    $fmt[] = '%d';

    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_user WHERE uid=%d and status=1 LIMIT 1", $this->uid) , ARRAY_A);

    if ($row) return array('statusCode' => 500, 'code' => 'activated');
    
    $result = $wpdb->insert($wpdb->prefix.'mynote_user', $val, $fmt);
    if ($result) {
      update_option('woonote_uuid_hash', esc_sql($request['hash']), false);
      update_option('woonote_user_count', intval($request['count']), false);
    }

    return array('statusCode' => $result > 0 ? 200 : 500);
  }

  /**
   * Matches the post data to the schema we want.
   *
   * @param WP_Post $post The comment object whose response is being prepared.
   */
  public function prepare_item_for_response( $post, $request ) {
    $post_data = array();

    $keys = array(
     'id' => 'ID',
     'uid' => 'post_author',
     'title' => 'post_title', 
     'excerpt' => 'post_excerpt',
     'content' => 'post_content',
     'status' => 'post_status', 
     'created_date' => 'post_date', 
     'updated_date' => 'post_modified',
     'updated_time' => 'post_modified',
     'term_id' => 'term_id'
    );
    $ia = is_array($post);
    foreach ($keys as $key => $name) {
      if ($key == 'id' || $key == 'uid' || $key == 'term_id') {
        $post_data[$key] = $ia ? (int)$post[$name] : (int)$post->$name;
      } elseif ($key == 'updated_time') {
        $post_data[$key] = strtotime($ia ? $post[$name] : $post->$name);
      } else {
        $post_data[$key] = $ia ? $post[$name] : $post->$name;
      }
    }

    return $post_data;
  }

  // Sets up the proper HTTP status code for authorization.
  public function authorization_status_code() {

    $status = 401;

    if ( is_user_logged_in() ) {
        $status = 403;
    }

    return $status;
  }
}

// Function to register our new routes from the controller.
function mynote_register_my_rest_routes() {
  $controller = new MyNote_Common_REST_Controller();
  $controller->register_routes();
}

add_action( 'rest_api_init', 'mynote_register_my_rest_routes' );

function mynote_func_folder_add_note($folderId, $noteId, $uid = 0) {
  global $wpdb;

  $noteId = (int)$noteId;
  if ($uid && $folderId > 0) {
    $newTerm = mynote_func_get_folder($folderId, $uid);
    if (!$newTerm) return false;
  }

  $rel = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_term_relation WHERE post_id=%d LIMIT 1", $noteId) , ARRAY_A);
    
  if ($rel && $rel['term_id'] == (int)$folderId) return true;

  $result = false;

  if ($rel) {
    $result = $wpdb->update($wpdb->prefix.'mynote_term_relation', array('term_id' => (int)$folderId), array('id' => $rel['id']), array('%d'), array('%d'));
  } else {
    $result = $wpdb->insert($wpdb->prefix.'mynote_term_relation', array('term_id' => (int)$folderId, 'post_id' => $noteId), array('%d', '%d'));
  }

  return $result > 0;
}

function mynote_func_folder_delete_note($folderId, $noteId) {
  global $wpdb;

  if ($folderId == 0) {
    $result = $wpdb->delete($wpdb->prefix.'mynote_term_relation', array('post_id' => (int)$noteId), array('%d'));
  } else {
    $result = $wpdb->delete($wpdb->prefix.'mynote_term_relation', array('term_id' => (int)$folderId, 'post_id' => (int)$noteId), array('%d', '%d'));
  }
  return $result > 0;
}

function mynote_func_get_note($id, $uid = 0, $refresh = false) {
  global $wpdb;

  $id = (int) $id;
  $uid = (int)$uid;
  if ( ! $id ) {
    return false;
  }

  $_note = wp_cache_get( $id, 'mynote_notes' );

  if ($refresh || !$_note ) {
    if ($uid > 0) {
      $_note = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE ID = %d AND post_author=%d LIMIT 1", $id, $uid ) );
    } else {
      $_note = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE ID = %d LIMIT 1", $id ) );
    }
    

    if ( ! $_note ) {
      return false;
    }

    $_note = sanitize_post( $_note, 'raw' );
    wp_cache_add( $_note->ID, $_note, 'mynote_notes' );

  } elseif ($uid > 0 && $_note->post_author != $uid) {
    return false;
  }

  return new WP_Post( $_note );
}

/*
get notes list
'page' => 1,
'per_page' => 5,
'post_type' => 'note',
'post_status' => 'private',
'uid' => $this->uid,
'folder_id' => null,
'resp_type' => 'null\detail'
'orderby' => 'ID\post_date\post_modified',
'order' => 'asc\desc'
*/
function mynote_func_get_notes( $args = null ) {
  global $wpdb;

  // $defaults = array(
  //   'orderby'          => 'post_date',
  //   'order'            => 'desc'
  // );

  $args = wp_parse_args( $args, /*$defaults*/);
  if (empty($args['orderby'])) $args['orderby'] = 'post_date';
  if (empty($args['order'])) $args['order'] = 'desc';

  $page = isset($args['page']) ? (int)$args['page'] : 1;
  $pagesize = isset($args['per_page']) ? (int)$args['per_page'] : 20;

  $w = [];
  $wv = ['replace_sql_str'];
  // where post_author (uid)
  if (!empty($args['uid'])) {
    $w[] = 'p.post_author=%d';
    $wv[] = (int)$args['uid'];
  }

  // where post_type
  $w[] = 'p.post_type=%s';
  $wv[] = 'note';

  // where post_status
  $validStatus = array('public', 'private');
  $stat = !empty($args['status']) && in_array($args['status'], $validStatus) ? $args['status'] : 'private';
  $w[] = 'p.post_status=%s';
  $wv[] = $stat;

  if (!empty($args['folder_id'])) {
    $w[] = 'tr.term_id=%d';
    $wv[] = (int)$args['folder_id'];
  }
  
  $w = implode(' AND ', $w);
  $offset = ($page - 1) * $pagesize;

  $getval = 'p.ID,p.post_author,p.post_title,p.post_excerpt'.($args['resp_type'] == 'detail' ? ',p.post_content':'').',p.post_status,p.post_date,p.post_modified,tr.term_id';

  $tp = $wpdb->prefix;

  // stat sql
  if (!empty($args['folder_id'])) {
    $statSql = "SELECT count(p.ID) FROM {$tp}posts p LEFT JOIN {$tp}mynote_term_relation tr ON p.ID=tr.post_id WHERE $w";
  } else {
    $statSql = "SELECT count(p.ID) FROM {$tp}posts p WHERE $w";
  }

  // order by posts ID\post_date\post_modified
  $orderFields = array('ID' => 'p.ID', 'post_date' => 'p.post_date', 'post_modified' => 'p.post_modified');
  $orderby = !empty($args['orderby']) && $orderFields[$args['orderby']] ? $args['orderby'] : '';
  $order = !empty($args['order']) && in_array($args['order'], array('asc', 'desc')) ? $args['order'] : 'desc';

  if ($orderby) {
    $sql = "SELECT $getval FROM {$tp}posts p LEFT JOIN {$tp}mynote_term_relation tr ON p.ID=tr.post_id WHERE $w ORDER BY {$orderFields[$orderby]} $order LIMIT $offset,$pagesize";
  } else {
    $sql = "SELECT $getval FROM {$tp}posts p LEFT JOIN {$tp}mynote_term_relation tr ON p.ID=tr.post_id WHERE $w LIMIT $offset,$pagesize";
  }

  // query count
  $wv[0] = $statSql;
  $query = call_user_func_array(array($wpdb, 'prepare'), $wv);
  $total = $wpdb->get_var($query);

  // query data
  $wv[0] = $sql;
  $query = call_user_func_array(array($wpdb, 'prepare'), $wv);
  $items = $wpdb->get_results($query, ARRAY_A);

  return array('total' => (int)$total, 'per_page' => $pagesize, 'items' => $items);
}

function mynote_func_get_folder_by_note($noteId) {
  global $wpdb;

  $term = $wpdb->get_row($wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_terms WHERE term_id IN (SELECT term_id FROM {$wpdb->prefix}mynote_term_relation WHERE post_id=%d) LIMIT 1", (int)$noteId) , ARRAY_A);

  return $term;
}

function mynote_func_get_folder_by_slug($slug, $uid) {
  global $wpdb;

  $uid = (int)$uid;

  $term = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_terms WHERE slug=%s AND uid=%d LIMIT 1", $slug, $uid ) , ARRAY_A);
    
  if ( ! $term ) {
    return false;
  }

  return $term;
}

function mynote_func_get_folder($id, $uid = 0, $refresh = false) {
  global $wpdb;

  static $cache = array();

  $id = (int) $id;
  $uid = (int)$uid;
  if ( !$id ) {
    return false;
  }

  $term = $cache[$id];

  if ($refresh || !$term) {
    if ($uid > 0) {
      $term = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_terms WHERE term_id = %d AND uid=%d LIMIT 1", $id, $uid ) , ARRAY_A);
    } else {
      $term = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}mynote_terms WHERE term_id = %d LIMIT 1", $id ) , ARRAY_A);
    }

    if ( ! $term ) {
      return false;
    }

    $cache[$term['term_id']] = $term;

  } elseif ($uid > 0 && $term['uid'] != $uid) {
    return false;
  }

  return $term;
}

function mynote_func_get_folders($args = null) {
  global $wpdb;

  $page = isset($args['page']) ? (int)$args['page'] : 1;
  $pagesize = isset($args['page_size']) ? (int)$args['page_size'] : 20;

  $w = [];
  $wv = [''];
  if (!empty($args['uid'])) {
    $w[] = 'uid=%d';
    $wv[] = (int)$args['uid'];
  }

  $tax = 'folder';
  $w[] = 'taxonomy=%s';
  $wv[] = $tax;

  $stat = !empty($args['status']) ? (int)$args['status'] : 1;
  $w[] = 'status=%d';
  $wv[] = $stat;

  $w = implode(' AND ', $w);
  $offset = ($page - 1) * $pagesize;
  $sql = "SELECT * FROM {$wpdb->prefix}mynote_terms WHERE $w ORDER BY term_id desc LIMIT $offset,$pagesize";

  $wv[0] = $sql;
  $query = call_user_func_array(array($wpdb, 'prepare'), $wv);
  $items = $wpdb->get_results($query, ARRAY_A);

  return $items;
}

function __returnResult($statusCode, $code, $data = null, $merge = false) {
  $data = $merge && !is_array($data) ? array('data' => $data) : $data;
  $result = $data && $merge ? $data : array();
  
  $result['statusCode'] = $statusCode;
  $result['code'] = $code;
  
  if (!$merge && $data) {
    $result['data'] = $data;
  }

  return $result;
}

function woonote_admin_add_settings_page() {
    add_options_page( 'WooNote settings', 'WooNote', 'manage_options', 'woonote-plugin', 'woonote_common_plugin_settings_page' );
}
add_action( 'admin_menu', 'woonote_admin_add_settings_page' );

function woonote_common_plugin_settings_page() {
    ?>
    <h2>WooNote Plugin Settings</h2>
    <form action="options.php" method="post">
        <?php 
        settings_fields( 'woonote_plugin_options' );
        do_settings_sections( 'woonote_plugin' ); ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
    </form>
    <?php
}

function woonote_register_settings() {
    register_setting( 'woonote_plugin_options', 'woonote_plugin_options', 'woonote_plugin_options_validate' );
    add_settings_section( 'common_settings', 'Common Settings', 'woonote_plugin_section_text', 'woonote_plugin' );
    add_settings_field( 'woonote_plugin_setting_app_id', 'AppId', 'woonote_plugin_setting_app_id', 'woonote_plugin', 'common_settings' );
    add_settings_field( 'woonote_plugin_setting_app_key', 'AppKey', 'woonote_plugin_setting_app_key', 'woonote_plugin', 'common_settings' );
}

function woonote_admin_init() {
  woonote_register_settings();
}

add_action( 'admin_init', 'woonote_admin_init' );

function woonote_plugin_section_text() {
    echo '<p>Here you can set all the options for using the plugin</p>';
}

function woonote_plugin_setting_app_id() {
    $options = get_option( 'woonote_plugin_options' );
    echo "<input id='woonote_plugin_setting_app_id' class='app_id_style' name='woonote_plugin_options[app_id]' type='text' value='".esc_attr( $options['app_id'] )."' />";
}

function woonote_plugin_setting_app_key() {
    $options = get_option( 'woonote_plugin_options' );
    echo "<input id='woonote_plugin_setting_app_key' class='app_key_style' name='woonote_plugin_options[app_key]' type='text' value='".esc_attr( $options['app_key'] )."' />";
}